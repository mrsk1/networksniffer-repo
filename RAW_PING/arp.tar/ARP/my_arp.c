#include "header.h"

int main()
{
	int sock_fd = -1;
	
	sock_fd = socket (AF_PACKET, SOCK_RAW, htons(ETH_P_ARP));
	
	if (sock_fd < 0) {
		perror("Socket");
		exit(EXIT_FAILURE);
	}
	
	printf ("Socket Created\n");	
	while(1) {	
		int rec_err_chk = -1;
		unsigned char recv_buffer[size];
		
		rec_err_chk = recvfrom (sock_fd, (void *)recv_buffer, size, 0 , NULL , NULL);

		if (rec_err_chk < 0) {
			perror("Recvfrom");
			exit(EXIT_FAILURE);
		}
		printf ("Size = %d\n", rec_err_chk);	
		
		int i = 0;/*! Temporary Iterative Variable*/
		
		ETHER_FRAME *eth;
		
		eth = (ETHER_FRAME *) recv_buffer;
	#if 0	
	/*
	Displays Ethernet Frame Format
	*/
		printf("Dest: ");
		for(i = 0; i < 6; i++)
			printf("%02x", eth -> dest[i]);
	
		printf("\nSrc: ");	
		for(i = 0; i < 6; i++)
			printf("%02x", eth -> src[i]);
		
		printf("\nType: %04x\n\n", ntohs (eth -> type));
	#endif
		ARP_FRAME *req;
	
		req = (ARP_FRAME *) (recv_buffer + sizeof(ETHER_FRAME));
	/*
	Displays ARP FRAMe FORMAT
	*/
	
//	printf("17.16.7.240 -> %04x\n", inet_addr("172.16.7.240"));	
//	printf("dest_ip : %04x\n", req -> dest_ip);
/*
	for(i = 0 ; i< 60 ; i++)	
	printf("%02x", recv_buffer[i]);	
	printf("\n");*/
		char ptr[size];
		inet_ntop(AF_INET, &(req -> dest_ip), ptr, size);
		printf("Dest : %s\n", ptr);
		int ret = 0;
	
		ret = strcmp("172.16.7.240", ptr);
		printf("RET = %d\n", ret);
	
		if(!ret) {	
		
		/*printf("Buffer: ");
		for (i = 0; i < 60 ; i++)
			printf("%02x", recv_buffer[i]);	
		
		printf("\n");*/
	/*	printf ("HW Type: %04x\n", req -> hw_type);
		printf ("Protocol Type: %04x\n", req -> p_type);
		printf ("Hardware Address Length: %02x\n", req -> ha_len);
		printf ("Protocol Length: %02x\n", req -> pa_len);
		printf ("Operation Code: %04x\n", htons(req -> opcode));
		printf ("Source MAC: ");
		for (i = 0 ; i < 6 ; i++)
			printf ("%02x", req -> src_mac[i]);
		printf ("\nSource IP: ");
		for (i = 0 ; i < 4 ; i++)
			printf ("%02x", req -> src_ip[i]);
		printf("\nDestination MAC: ");
		for (i = 0 ; i < 6 ; i++)
			printf ("%02x", req -> dest_mac[i]);
		printf ("\nDest IP: ");		
		for (i = 0 ; i < 4 ; i++)
			printf ("%02x", req -> dest_ip[i]);
	
		printf("\n");*/
		
		char send_buffer[size];	
	/*	sprintf(send_buffer,
		"%02x%02x%02x%02x%02x%02x"
		"a4badbeec8660806"
		"%04x%04x%02x%02x0002"
		"a4badbeec866"
		"%02x%02x%02x%02x"
		"%02x%02x%02x%02x%02x%02x"
		"%02x%02x%02x%02x\0",
		req -> src_mac[0], req -> src_mac[1],
		req -> src_mac[2], req -> src_mac[3],
		req -> src_mac[4], req -> src_mac[5],
		req -> hw_type, req -> pa_len, req -> ha_len, req -> pa_len, 
		req -> dest_ip[0], req -> dest_ip[1], req -> dest_ip[2], req -> dest_ip[3],	
		req -> src_mac[0], req -> src_mac[1],
		req -> src_mac[2], req -> src_mac[3],
		req -> src_mac[4], req -> src_mac[5],
		req -> src_ip[0], req -> src_ip[1], req -> src_ip[2], req -> src_ip[3]);
		
		for(i = 0 ; i< 60 ; i++)	
			printf("%02x", send_buffer[i]);	
		printf("\n");
		*/
		REPLY_PKT *rep;
		rep = (REPLY_PKT *) send_buffer;/*Check the necessity of this line*/
	
		memcpy (rep -> dest, eth -> dest, sizeof (eth -> dest));
		memcpy (rep -> src, eth -> src, sizeof (eth -> src));
		rep -> type = eth -> type;
		
		memcpy (rep -> src_mac, req -> src_mac, sizeof (req -> src_mac));
		memcpy (&(rep -> hw_type), &(req -> hw_type), sizeof (req -> hw_type));
		memcpy (&(rep -> p_type), &(req -> p_type), sizeof (req -> p_type));
		memcpy (&(rep -> ha_len), &(req -> ha_len), sizeof (req -> ha_len));
		memcpy (&(rep -> pa_len), &(req -> pa_len), sizeof (req -> pa_len));
		memcpy (&(rep -> src_mac), "a4badbeec866", sizeof ("a4badbeec866"));
		memcpy (rep -> src_ip, req -> dest_ip, sizeof (req -> dest_ip));
		memcpy (rep -> dest_mac, req -> src_mac, sizeof (req -> src_mac));
		memcpy (rep -> dest_ip, req -> src_ip, sizeof (req -> src_ip));
		
	
		memcpy(send_buffer, rep, sizeof (rep));	
			
		printf("\nlen = %d\n", strlen (send_buffer));	
		
		
		for(i = 0 ; i < strlen (send_buffer) ; i++)	
			printf("%02x", send_buffer[i]);	
		printf("\n");
		struct sockaddr_in dest;
		dest.sin_family = AF_INET;
//		dest.sin_port = 
		dest.sin_addr.s_addr = inet_addr((const char *)&req -> src_ip);	
		int send = 0;
		send = sendto (sock_fd, send_buffer, strlen(send_buffer), 0, (struct sockaddr *) &dest, (socklen_t) size);	
		
		if (send == -1) {
			perror("Send");
		}
		}
	}
	return EXIT_SUCCESS;
}
		
		
