#ifndef header
#define header
	
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <errno.h>	

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <linux/if_ether.h>
#include "my_struc.h"

#define size 4096

#endif
